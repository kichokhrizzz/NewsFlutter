# News App
Esta es una aplicación hecha en Flutter siguiendo mi curso completo, el cual puedes inscribirte aquí:

[Flutter: Tu guía completa de desarrollo para IOS y Android](https://fernando-herrera.com/#/curso/flutter)

![App](https://fernando-herrera.com/github/flutter/goal2.png)